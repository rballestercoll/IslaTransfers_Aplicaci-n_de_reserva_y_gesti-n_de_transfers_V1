<?php $__env->startSection('title', 'Gestión hoteles'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary">
            <i class="fa-solid fa-hotel me-2"></i>Lista de hoteles registrados
        </h2>
        <button type="button" class="btn btn-primary fw-bold shadow-sm d-flex align-items-center"
            data-bs-toggle="modal" data-bs-target="#newHotelModal">
            <i class="fa-solid fa-square-h me-2"></i> Añadir hotel
        </button>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-primary">
                        <tr>
                            <th>Nombre del hotel</th>
                            <th>Zona del hotel</th>
                            <th>Comisión</th>
                            <th>Email</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hoteles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($hotel->nombre_hotel); ?></td>
                            <td><?php echo e(optional($hotel->zona)->descripcion ?? 'Zona no asignada'); ?></td>
                            <td><?php echo e($hotel->comision); ?>%</td>
                            <td><?php echo e($hotel->email_hotel); ?></td>
                            <td>
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-sm btn-warning editHotelBtn"
                                        data-id="<?php echo e($hotel->id_hotel); ?>"
                                        data-nombre="<?php echo e($hotel->nombre_hotel); ?>"
                                        data-comision="<?php echo e($hotel->comision); ?>"
                                        data-email="<?php echo e($hotel->email_hotel); ?>"
                                        data-zona="<?php echo e($hotel->id_zona); ?>">
                                        <i class="fa-solid fa-pen-to-square me-1"></i>Editar
                                    </button>

                                    <form action="<?php echo e(route('admin.hotel.destroy', $hotel->id_hotel)); ?>" method="POST">

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"
                                            onclick="return confirm('¿Eliminar este hotel?')">
                                            <i class="fa-solid fa-trash me-1"></i>Eliminar
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('modals.admin.hotel.edit_hotel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modals.admin.hotel.new_hotel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.querySelectorAll('.editHotelBtn').forEach(button => {
        button.addEventListener('click', () => {
            const id = button.dataset.id;
            document.getElementById('editHotelId').value = id;
            document.getElementById('editHotelForm').action = `/admin/hotel/${id}`;
            document.getElementById('editHotelName').value = button.dataset.nombre;
            document.getElementById('editHotelCommission').value = button.dataset.comision;
            document.getElementById('editHotelEmail').value = button.dataset.email;
            document.getElementById('editHotelZona').value = button.dataset.zona;
            document.getElementById('editHotelPassword').value = button.dataset.password;
            const modal = new bootstrap.Modal(document.getElementById('editHotelModal'));
            modal.show();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/panel/admin/hotel/adminHotel.blade.php ENDPATH**/ ?>