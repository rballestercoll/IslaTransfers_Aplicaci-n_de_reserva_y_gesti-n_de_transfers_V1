<h2>Resumen de reservas por hotel</h2>

<table border="1" cellpadding="8" cellspacing="0">
    <thead>
        <tr>
            <th>Hotel</th>
            <th>Email</th>
            <th>Reservas</th>
            <th>Pasajeros</th>
            <th>Comisión/Reserva (€)</th>
            <th>Total Comisión (€)</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $resumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($hotel['descripcion']); ?></td>
                <td><?php echo e($hotel['email']); ?></td>
                <td><?php echo e($hotel['reservas']); ?></td>
                <td><?php echo e($hotel['pasajeros']); ?></td>
                <td><?php echo e($hotel['comision']); ?></td>
                <td><strong><?php echo e($hotel['total']); ?></strong></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /var/www/html/resources/views/panel/admin_hotel_resumen.blade.php ENDPATH**/ ?>