<?php
// views/templates/footer.php
?>
<footer class="main-footer">
  <p>&copy; <?php echo date('Y'); ?> Isla Transfers. Todos los derechos reservados.</p>
</footer>
<script src="assets/js/script.js"></script>
</body>
</html>
