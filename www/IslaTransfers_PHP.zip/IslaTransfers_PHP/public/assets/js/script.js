// assets/js/script.js

// Código JavaScript para interacciones simples
document.addEventListener("DOMContentLoaded", () => {
  console.log("Isla Transfers - FrontEnd cargado correctamente.");
  // Ejemplo: Podrías manejar clicks de botones, animaciones, etc.
});
