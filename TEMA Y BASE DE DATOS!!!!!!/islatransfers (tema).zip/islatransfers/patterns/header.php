<?php
/**
 * Title: header
 * Slug: islatransfers/header
 * Inserter: no
 */
?>
<!-- wp:group {"align":"full","className":"eplus-wrapper","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull eplus-wrapper"><!-- wp:group {"className":"eplus-wrapper","style":{"border":{"width":"0px","style":"none"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group eplus-wrapper" style="border-style:none;border-width:0px"><!-- wp:group {"align":"wide","className":"eplus-wrapper","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"textColor":"contrast","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignwide eplus-wrapper has-contrast-color has-text-color has-link-color" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:image {"lightbox":{"enabled":false},"width":"180px","height":"auto","sizeSlug":"full","linkDestination":"custom","className":"is-style-default eplus-wrapper","style":{"spacing":{"margin":{"right":"0","left":"0","top":"0","bottom":"0"}},"layout":{"selfStretch":"fit","flexSize":null},"border":{"width":"0px","style":"none"}}} -->
<figure class="wp-block-image size-full is-resized has-custom-border is-style-default eplus-wrapper" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0"><a href="http://localhost:8081/"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Captura-removebg-preview-1-4.png" alt="" class="" style="border-style:none;border-width:0px;width:180px;height:auto"/></a></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"eplus-wrapper","style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"right"}} -->
<div class="wp-block-group eplus-wrapper"><!-- wp:navigation {"overlayBackgroundColor":"base","overlayTextColor":"contrast","className":"","layout":{"type":"flex","justifyContent":"right","flexWrap":"wrap"}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->